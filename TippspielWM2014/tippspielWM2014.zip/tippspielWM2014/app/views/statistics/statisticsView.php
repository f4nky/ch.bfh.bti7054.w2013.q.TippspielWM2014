<h1>Statistik</h1>
<h2>Punktzahl</h2>
<table>
	<colgroup>
		<col width="30%">
		<col width="30%">
		<col width="20%">
		<col width="20%">
	</colgroup>
	<thead>
		<th></th>
		<th class="right">Ausgewertete Spiele</th>
		<th class="right">Mögliche Punktzahl</th>
		<th class="right">Deine Punktzahl</th>
	</thead>
	<tbody>
		<tr>
			<td>Anzahl</td>
			<td class="right">7</td>
			<td class="right">35</td>
			<td class="right">15</td>
		</tr>
	</tbody>
</table>
<h2>Allgemeine Tipps</h2>
<table>
	<colgroup>
		<col width="20%">
		<col width="20%">
		<col width="20%">
		<col width="20%">
		<col width="20%">
	</colgroup>
	<thead>
		<th></th>
		<th class="right">Total aktuell</th>
		<th class="right">Durchschnitt/Spiel</th>
		<th class="right">Hochrechnung (64 Spiele)</th>
		<th class="right">Dein Tipp</th>
	</thead>
	<tbody>
		<tr>
			<td>Tore</td>
			<td class="right">28</td>
			<td class="right">1.65</td>
			<td class="right">105.41</td>
			<td class="right">113</td>
		</tr>
		<tr>
			<td>Gelbe Karten</td>
			<td class="right">58</td>
			<td class="right">3.41</td>
			<td class="right">218.35</td>
			<td class="right">231</td>
		</tr>
		<tr>
			<td>Rote Karten</td>
			<td class="right">5</td>
			<td class="right">0.29</td>
			<td class="right">18.82</td>
			<td class="right">15</td>
		</tr>
	</tbody>
</table>
<br />
<p id="errMsg">Dies ist eine statische html-Seite. Aufbereitung dieser Seite nicht im Projektumfang enthalten.</p>
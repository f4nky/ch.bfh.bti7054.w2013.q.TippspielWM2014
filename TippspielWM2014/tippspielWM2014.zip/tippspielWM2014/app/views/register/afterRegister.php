<h1>Danke</h1>
<p>Danke für deine Registrierung. Da es sich um ein privates Tippspiel handelt, muss dein Account zuerst von einem Administrator freigeschaltet werden.</p>
<p>Du wirst per E-Mail informiert, sobald dies geschehen ist.<br />
	<span id="errMsg">(Diese Funktionalität ist noch nicht implementiert.)</span></p>
<p>Danke für dein Verständnis und viel Spass beim Tippen.</p>
<p>Liebe Grüsse<br />
Fanky</p>
<h1>Hast du dich vertippt?</h1>
<p>Die von dir gewünschte Seite kann nicht gefunden werden.</p>
<p>Folgende Seiten stehen dir zur Verfügung:</p>
<?php include('app/views/navigation.inc.php'); ?>
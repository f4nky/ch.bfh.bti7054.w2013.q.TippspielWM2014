<h1>Impressum</h1>
<h2>Webdesign & Webmaster</h2>
<p>Michael Fankhauser<br />
Pestalozzistrasse 55<br />
CH-3600 Thun<br />
Switzerland</p>

<h2>Rechtliche Hinweise</h2>
<p>Ich übernehme keinerlei Garantie für die Aktualität, die inhaltliche Richtigkeit, die Vollständigkeit und die Qualität der bereitgestellten Informationen.</p>

<h3>Haftungshinweis</h3>
<p>Trotz sorgfältiger inhaltlicher Kontrolle übernehme ich keine Haftung für die Inhalte externer Links. Für den Inhalt der verlinkten Seiten sind ausschliesslich deren Betreiber verantwortlich.</p>

<h3>Copyright</h3>
<p>Das auf dieser Website enthaltene Bild- und Text-Material darf ohne Zustimmung von Michael Fankhauser (Fanky) weder ganz noch teilweise verwendet werden.</p>

<h2>Technik</h2>
<p>Diese Website ist für Mozilla, Safari und IE9 optimiert.
Empfohlene Auflösung: 1280×1024, minimale Auflösung: 1024×768.
Javascript ist für einige Funktionen erforderlich und sollte aktiviert sein.
Der Code dieser Website entspricht den W3C-Standards.</p>
<section class="box">
	<section class="title">Ad<span>min</span></section>
	<section class="content">
		<a href="adminPlayer">&raquo; Admin Teilnemer</a><br />
		<a href="adminResult">&raquo; Resultate eintragen</a><br />
	</section>
</section>
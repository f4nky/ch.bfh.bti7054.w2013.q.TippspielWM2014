				</section>
				<div style="clear: both;"></div>
			</section>
			<footer>copyright &copy; 2014 Fanky &middot; <a href="impressum">Impressum</a></footer>
		</div>
	</body>
</html>
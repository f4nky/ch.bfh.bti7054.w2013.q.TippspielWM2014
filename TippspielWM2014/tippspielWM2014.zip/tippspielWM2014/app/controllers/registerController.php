<?php
/**
* Controller für die Registrierung.
*
* @author		Fanky
* @copyright	2014 Fanky
* @version		1.0 released 14.01.2014
*/
class RegisterController extends Controller {

	public function __construct() {
		parent::__construct();
		//Auth::handleLogin();
	}

	/**
	 * Lädt die Default-View.
	 */
	public function loadView() {
		$this->view->title = 'Registrierung';
		$this->view->render('register/registerView');
	}

	/**
	 * Lädt die Bestätigungs-View für nach der Registrierung
	 */
	public function loadAfterRegisterView() {
		$this->view->render('register/afterRegister');
	}

	/**
	 * Ruft die Methode zum Registrieren des Teilnehmers auf und leitet ihn auf die Bestätigungs-View weiter.
	 */
	public function registerPlayer() {
		try {
			$this->model->registerPlayer();
			header('Location: ' . SITE_PATH . 'register/loadAfterRegisterView');
			exit;
		} catch (Exception $e) {
			$this->view->formData = $this->model->getPostedData();
			$this->view->errMsg = $e->getMessage();
			$this->loadView();
		}
	}
}
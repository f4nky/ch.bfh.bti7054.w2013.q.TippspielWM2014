<?php
/**
* Controller für den Ranglisten-Bereich.
*
* @author		Fanky
* @copyright	2014 Fanky
* @version		1.0 released 14.01.2014
*/
class RankingController extends Controller {

	public function __construct() {
		parent::__construct();
		Auth::handleLogin();
	}

	/**
	 * Holt diverse Daten und weist der View zusätzlich ein js- und ein css-File zu.
	 */
	public function loadView() {
		$this->view->title = 'Rangliste';
		$this->view->data = $this->getRanking();
		$this->view->dataChart = $this->getRankingForChart();
		$this->view->js = $this->getJqPlotPathes();
		$this->view->css = array('jquery.jqplot.min.css');
		$this->view->render('ranking/rankingView');
	}
	
	/**
	 * Holt die Daten und lädt die Teil-View für die Sidebar.
	 */
	public function loadBoxView() {
		$this->view->data = $this->getPartialRanking();
		$this->view->render('sidebar/rankingBoxView', true);
	}
	
	/**
	 * Holt die komplette Rangliste.
	 */
	public function getRanking() {
		return $this->model->getRanking();
	}

	/**
	 * Holt die Daten für die Graphik in json-Format.
	 */
	public function getRankingForChart() {
		return $this->model->getRankingForChart();
	}

	/**
	 * Holt die Daten für die Teil-Rangliste.
	 */
	public function getPartialRanking() {
		return $this->model->getPartialRanking();
	}

	/**
	 * Liefert einen Array mit den zu ladenden js-Scripten zurück.
	 */
	public function getJqPlotPathes() {
		$files = array(
			'jqplot/jquery.jqplot.min.js',
			'jqplot/jqplot.barRenderer.min.js',
			'jqplot/jqplot.canvasAxisLabelRenderer.min.js',
			'jqplot/jqplot.canvasAxisTickRenderer.min.js',
			'jqplot/jqplot.canvasTextRenderer.min.js',
			'jqplot/jqplot.categoryAxisRenderer.min.js',
			'jqplot/jqplot.dateAxisRenderer.min.js',
			'jqplot/jqplot.logAxisRenderer.min.js',
			'jqplot/jqplot.pointLabels.min.js',
			'jqplot/jqplotFuncs.js'
		);
		return $files;
	}
}
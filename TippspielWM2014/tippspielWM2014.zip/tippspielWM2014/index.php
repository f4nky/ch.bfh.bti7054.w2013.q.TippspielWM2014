<?php
/**
* Haupteinstiegspunkt der Website. Erstellt einen neuen Request, welcher
* die GET-Variable 'url' ausliest und verarbeitet und liefert die Teile an 
* die Bootstrap-Klasse. Diese ruft dann den entsprechenden Controller mit
* der dazugehörigen Methode auf.
*
* Die Libraries werden automatisch bei Verwendung geladen.
*
* @author		Fanky
* @copyright	2014 Fanky
* @version		1.0 released 14.01.2014
*/
require_once 'config/config.php';
require_once 'util/auth.php';

function __autoload($class) {
	require LIB . $class . '.php';
}

$app = Bootstrap::load(new Request());
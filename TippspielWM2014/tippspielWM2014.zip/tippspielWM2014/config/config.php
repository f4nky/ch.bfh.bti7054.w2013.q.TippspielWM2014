<?php
// paths
define('SITE_PATH', 'http://localhost/tippspielWM2014/');
define('APP_PATH', 'app/');
define('LIB', 'lib/');

// database
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'tippspielWM2014');

// init password
define('INIT_PWD', Password::hash('TippspielWM2014'));